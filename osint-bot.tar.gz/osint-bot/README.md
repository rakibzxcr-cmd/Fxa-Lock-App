# 👁️ OSINT Telegram Bot

Open Source Intelligence toolkit running as a Telegram bot.

## Features

| Tool | Description |
|------|-------------|
| 🔍 Username Lookup | Scans 20+ platforms concurrently |
| 📧 Email Lookup | MX check + Hunter.io source search |
| 🌐 IP Lookup | ip-api.com (free, no key) |
| 💥 Breach Checker | HaveIBeenPwned v3 |
| 📱 Phone Lookup | Numverify carrier/country + social ID search |
| 👤 Social Scraper | Instagram, TikTok, Twitter/X, GitHub |
| ✈️ Telegram Lookup | t.me preview + Fragment.telegram.org |
| ⭐ Voting | Inline star ratings on every result |

---

## Deploy to GitHub + Render

### 1. Create Telegram Bot
1. Open [@BotFather](https://t.me/BotFather)
2. `/newbot` → set name and username
3. Copy the token

### 2. Push to GitHub
```bash
git init
git add .
git commit -m "init"
git remote add origin https://github.com/YOUR_USERNAME/osint-bot.git
git push -u origin main
```

### 3. Deploy on Render
1. Go to [render.com](https://render.com) → New → **Background Worker**
2. Connect your GitHub repo
3. Set **Build Command**: `pip install -r requirements.txt`
4. Set **Start Command**: `python main.py`
5. Add Environment Variables (see below)
6. Deploy

---

## Environment Variables

| Key | Required | Where to get |
|-----|----------|--------------|
| `BOT_TOKEN` | ✅ | @BotFather |
| `HIBP_API_KEY` | For breach checker | [haveibeenpwned.com/API/Key](https://haveibeenpwned.com/API/Key) (~$3.50/month) |
| `NUMVERIFY_KEY` | For phone carrier | [numverify.com](https://numverify.com) (free tier: 100 req/month) |
| `HUNTER_API_KEY` | For email sources | [hunter.io](https://hunter.io) (free: 25 searches/month) |
| `IPINFO_TOKEN` | Optional IP enrichment | [ipinfo.io](https://ipinfo.io) (free: 50K req/month) |

**IP Lookup works with zero keys** (uses ip-api.com free tier).

---

## Commands

| Command | Action |
|---------|--------|
| `/start` | Main menu |
| `/stats` | Voting statistics |
| `/cancel` | Back to menu |

---

## Notes

- **Telegram phone lookup**: Telegram does not expose phone numbers via public API. The bot returns profile metadata from t.me preview. Actual number requires Telegram client API + mutual contact.
- **TikTok social ID from phone**: No public API exists. Phone lookup returns carrier data.
- **Votes**: Stored in `votes.json` on the Render instance. For multi-instance scaling, replace with Redis.
