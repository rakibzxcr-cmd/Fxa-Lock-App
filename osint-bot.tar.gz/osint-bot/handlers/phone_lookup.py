import re
import requests
from bs4 import BeautifulSoup
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import vote_keyboard, back_keyboard
from utils.formatters import fmt_phone
from config import AWAITING_PHONE, NUMVERIFY_KEY
import uuid

PHONE_RE = re.compile(r"^\+?[\d\s\-\(\)]{7,20}$")

async def ask_phone(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text(
        "📱 *Phone Lookup*\n\n"
        "Send a phone number in international format.\n\n"
        "Example: `+905551234567`\n\n"
        "Returns:\n"
        "• Carrier & line type\n"
        "• Country & location\n"
        "• Facebook / Instagram / TikTok ID search\n"
        "• Number format validation",
        parse_mode="Markdown",
        reply_markup=back_keyboard(),
    )
    return AWAITING_PHONE

def _numverify_lookup(number: str) -> dict:
    if not NUMVERIFY_KEY:
        return {"error": "NUMVERIFY_KEY not set"}
    r = requests.get(
        "http://apilayer.net/api/validate",
        params={
            "access_key": NUMVERIFY_KEY,
            "number": number,
            "country_code": "",
            "format": "1",
        },
        timeout=8,
    )
    return r.json()

def _facebook_id_from_phone(number: str) -> str:
    """
    Attempt to find Facebook profile linked to phone via public search.
    Returns profile URL or None.
    """
    try:
        clean = re.sub(r"[\s\-\(\)\+]", "", number)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        # Check if number is linked to a FB account via mobile login page
        r = requests.get(
            "https://www.facebook.com/login/identify",
            params={"ctx": "recover", "q": clean},
            headers=headers,
            timeout=8,
            allow_redirects=True,
        )
        if "profile" in r.url or "checkpoint" in r.url:
            return r.url
        soup = BeautifulSoup(r.text, "html.parser")
        link = soup.find("a", href=re.compile(r"facebook\.com/profile"))
        if link:
            return link["href"]
    except Exception:
        pass
    return None

def _instagram_id_from_phone(number: str) -> str:
    """
    Instagram doesn't expose phone-to-ID publicly; check via people search.
    """
    try:
        clean = re.sub(r"[\s\-\(\)\+]", "", number)
        headers = {
            "User-Agent": "Instagram 76.0.0.15.395 Android",
            "Accept-Language": "en-US",
        }
        r = requests.get(
            "https://www.instagram.com/api/v1/users/lookup_phone/",
            params={"phone": clean},
            headers=headers,
            timeout=6,
        )
        if r.status_code == 200:
            data = r.json()
            uid = data.get("user_id") or data.get("id")
            if uid:
                return str(uid)
    except Exception:
        pass
    return None

def _tiktok_id_from_phone(number: str) -> str:
    """
    TikTok does not expose phone-to-ID via public API.
    Returns None; placeholder for manual OSINT.
    """
    return None

async def handle_phone(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text.strip()
    if text == "🏠 Main Menu":
        from handlers.start import start
        return await start(update, ctx)

    if not PHONE_RE.match(text):
        await update.message.reply_text(
            "❌ Invalid format. Use international format: `+905551234567`",
            parse_mode="Markdown",
            reply_markup=back_keyboard(),
        )
        return AWAITING_PHONE

    await update.message.reply_text("🔎 Running phone intelligence...")

    # -- Numverify lookup --
    nv_data = _numverify_lookup(text)
    result_id = str(uuid.uuid4())[:8]
    ctx.user_data[f"result_{result_id}"] = {"type": "phone", "query": text}

    if "error" in nv_data and "NUMVERIFY_KEY" in nv_data.get("error", ""):
        # Fallback: basic formatting only
        clean = re.sub(r"[\s\-\(\)]", "", text)
        nv_data = {
            "valid": bool(PHONE_RE.match(text)),
            "international_format": clean,
            "local_format": clean,
            "country_name": "N/A (set NUMVERIFY_KEY for full data)",
            "country_code": "N/A",
            "carrier": "N/A",
            "line_type": "N/A",
            "location": "N/A",
        }

    msg = fmt_phone(nv_data, text)

    # -- Social ID search --
    msg += "\n\n🔗 *Social ID Search*\n━━━━━━━━━━━━━━━━━━━"

    fb = _facebook_id_from_phone(text)
    msg += f"\n📘 Facebook: {fb if fb else '❌ Not found / private'}"

    ig = _instagram_id_from_phone(text)
    msg += f"\n📸 Instagram ID: {ig if ig else '❌ Not exposed publicly'}"

    msg += f"\n🎵 TikTok: ❌ No public phone-to-ID API"

    await update.message.reply_text(
        msg,
        parse_mode="Markdown",
        reply_markup=vote_keyboard(result_id),
    )
    return AWAITING_PHONE
