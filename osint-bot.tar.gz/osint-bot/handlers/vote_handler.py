import json
import os
from collections import defaultdict
from telegram import Update
from telegram.ext import ContextTypes

# In-memory vote store (persists per process; for multi-instance use Redis)
_votes: dict = defaultdict(list)   # result_id -> list of (user_id, stars)

def _save_votes():
    """Persist votes to votes.json (for single-instance Render deploy)."""
    try:
        with open("votes.json", "w") as f:
            json.dump({k: v for k, v in _votes.items()}, f)
    except Exception:
        pass

def _load_votes():
    if os.path.exists("votes.json"):
        try:
            with open("votes.json") as f:
                data = json.load(f)
                for k, v in data.items():
                    _votes[k] = v
        except Exception:
            pass

_load_votes()

STARS = {1: "⭐", 2: "⭐⭐", 3: "⭐⭐⭐", 4: "⭐⭐⭐⭐", 5: "⭐⭐⭐⭐⭐"}

async def handle_vote(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    try:
        _, stars_str, result_id = query.data.split(":")
        stars = int(stars_str)
    except (ValueError, AttributeError):
        return

    user_id = query.from_user.id

    # Check if user already voted on this result
    existing = [v for v in _votes[result_id] if v[0] == user_id]
    if existing:
        await query.answer("You already rated this result.", show_alert=True)
        return

    _votes[result_id].append((user_id, stars))
    _save_votes()

    all_stars = [v[1] for v in _votes[result_id]]
    avg = sum(all_stars) / len(all_stars)
    total = len(all_stars)

    result_meta = ctx.user_data.get(f"result_{result_id}", {})
    result_type = result_meta.get("type", "result")
    result_query = result_meta.get("query", "")

    await query.edit_message_text(
        f"✅ *Vote recorded!*\n\n"
        f"You rated: {STARS[stars]} ({stars}/5)\n"
        f"Result: `{result_query}` [{result_type}]\n\n"
        f"📊 Average: {avg:.1f}/5 from {total} vote(s)",
        parse_mode="Markdown",
    )

async def stats_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """Show overall voting stats — /stats command."""
    if not _votes:
        await update.message.reply_text("📊 No votes recorded yet.")
        return

    total_votes = sum(len(v) for v in _votes.values())
    total_results = len(_votes)
    all_stars = [s for votes in _votes.values() for _, s in votes]
    avg = sum(all_stars) / len(all_stars) if all_stars else 0

    await update.message.reply_text(
        f"📊 *Bot Statistics*\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"Total lookups rated: {total_results}\n"
        f"Total votes cast: {total_votes}\n"
        f"Overall average: {avg:.2f}/5\n",
        parse_mode="Markdown",
    )
