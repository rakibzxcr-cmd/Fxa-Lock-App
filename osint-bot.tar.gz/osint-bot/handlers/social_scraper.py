import re
import requests
from bs4 import BeautifulSoup
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import vote_keyboard, back_keyboard
from utils.formatters import fmt_social
from config import AWAITING_SOCIAL
import uuid
import json

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

def _scrape_instagram(username: str) -> dict:
    try:
        r = requests.get(
            f"https://www.instagram.com/{username}/",
            headers={**HEADERS, "X-Requested-With": "XMLHttpRequest"},
            timeout=8,
        )
        if r.status_code == 404:
            return {"found": False}

        soup = BeautifulSoup(r.text, "html.parser")
        # Try to extract from meta tags
        meta_title = soup.find("meta", property="og:title")
        meta_desc = soup.find("meta", property="og:description")
        name = meta_title["content"] if meta_title else None
        bio = meta_desc["content"] if meta_desc else None

        # Strip follower count from description
        followers = None
        if bio:
            m = re.search(r"([\d,\.]+[KMBk]?)\s*Followers", bio)
            if m:
                followers = m.group(1)

        return {
            "found": True,
            "data": {
                "name": name,
                "bio": bio,
                "followers": followers,
                "url": f"https://www.instagram.com/{username}/",
            },
        }
    except Exception as e:
        return {"found": False, "error": str(e)}

def _scrape_tiktok(username: str) -> dict:
    try:
        r = requests.get(
            f"https://www.tiktok.com/@{username}",
            headers=HEADERS,
            timeout=8,
        )
        if r.status_code == 404:
            return {"found": False}

        soup = BeautifulSoup(r.text, "html.parser")
        meta_title = soup.find("meta", property="og:title")
        meta_desc = soup.find("meta", property="og:description")
        name = meta_title["content"] if meta_title else None
        bio = meta_desc["content"] if meta_desc else None

        followers = None
        if bio:
            m = re.search(r"([\d,\.]+[KMBk]?)\s*Followers", bio, re.IGNORECASE)
            if m:
                followers = m.group(1)

        return {
            "found": r.status_code == 200,
            "data": {
                "name": name,
                "bio": bio,
                "followers": followers,
                "url": f"https://www.tiktok.com/@{username}",
            },
        }
    except Exception as e:
        return {"found": False, "error": str(e)}

def _scrape_twitter(username: str) -> dict:
    try:
        r = requests.get(
            f"https://twitter.com/{username}",
            headers=HEADERS,
            timeout=8,
        )
        soup = BeautifulSoup(r.text, "html.parser")
        meta_title = soup.find("meta", property="og:title")
        meta_desc = soup.find("meta", property="og:description")
        name = meta_title["content"] if meta_title else None
        bio = meta_desc["content"] if meta_desc else None

        if r.status_code == 404 or (bio and "this account doesn't exist" in bio.lower()):
            return {"found": False}

        return {
            "found": r.status_code == 200,
            "data": {
                "name": name,
                "bio": bio,
                "url": f"https://twitter.com/{username}",
            },
        }
    except Exception:
        return {"found": False}

def _scrape_github(username: str) -> dict:
    try:
        r = requests.get(
            f"https://api.github.com/users/{username}",
            headers={"Accept": "application/vnd.github+json"},
            timeout=8,
        )
        if r.status_code == 404:
            return {"found": False}
        d = r.json()
        return {
            "found": True,
            "data": {
                "name": d.get("name"),
                "bio": d.get("bio"),
                "followers": d.get("followers"),
                "url": d.get("html_url"),
                "repos": d.get("public_repos"),
                "company": d.get("company"),
                "location": d.get("location"),
            },
        }
    except Exception:
        return {"found": False}

SCRAPERS = {
    "Instagram": _scrape_instagram,
    "TikTok": _scrape_tiktok,
    "Twitter/X": _scrape_twitter,
    "GitHub": _scrape_github,
}

async def ask_social(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text(
        "👤 *Social Media Scraper*\n\n"
        "Send a username to scrape public info from:\n"
        "• Instagram\n• TikTok\n• Twitter/X\n• GitHub\n\n"
        "Example: `elonmusk`",
        parse_mode="Markdown",
        reply_markup=back_keyboard(),
    )
    return AWAITING_SOCIAL

async def handle_social(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text.strip()
    if text == "🏠 Main Menu":
        from handlers.start import start
        return await start(update, ctx)

    if len(text) < 2 or len(text) > 60 or " " in text:
        await update.message.reply_text("❌ Invalid username.", reply_markup=back_keyboard())
        return AWAITING_SOCIAL

    msg = await update.message.reply_text("🔎 Scraping public social profiles...")

    results = {}
    for platform, scraper in SCRAPERS.items():
        results[platform] = scraper(text)

    result_id = str(uuid.uuid4())[:8]
    ctx.user_data[f"result_{result_id}"] = {"type": "social", "query": text}

    output = fmt_social(text, results)
    if len(output) > 4000:
        output = output[:4000] + "\n\n...truncated."

    await msg.edit_text(output, parse_mode="Markdown")
    await update.message.reply_text(
        "⭐ Rate this result:",
        reply_markup=vote_keyboard(result_id),
    )
    return AWAITING_SOCIAL
