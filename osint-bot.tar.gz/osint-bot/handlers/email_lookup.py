import re
import requests
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import vote_keyboard, back_keyboard
from utils.formatters import fmt_email
from config import AWAITING_EMAIL, HUNTER_API_KEY
import uuid
import dns.resolver

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

DISPOSABLE_DOMAINS = {
    "mailinator.com", "guerrillamail.com", "10minutemail.com",
    "tempmail.com", "throwaway.email", "sharklasers.com",
    "guerrillamailblock.com", "grr.la", "guerrillamail.info",
    "spam4.me", "yopmail.com", "maildrop.cc", "dispostable.com",
}

def _check_mx(domain: str) -> bool:
    try:
        answers = dns.resolver.resolve(domain, "MX", lifetime=5)
        return len(answers) > 0
    except Exception:
        return False

def _check_email_basic(email: str) -> dict:
    domain = email.split("@")[1].lower()
    has_mx = _check_mx(domain)
    is_disposable = domain in DISPOSABLE_DOMAINS
    free_providers = {
        "gmail.com", "yahoo.com", "hotmail.com", "outlook.com",
        "protonmail.com", "icloud.com", "aol.com", "mail.com",
    }
    role_prefixes = {"admin", "info", "support", "help", "noreply", "no-reply",
                     "contact", "sales", "team", "hello", "marketing"}
    local = email.split("@")[0].lower()
    is_role = local in role_prefixes

    return {
        "valid_format": bool(EMAIL_RE.match(email)),
        "domain": domain,
        "mx_records": has_mx,
        "deliverable": "likely" if has_mx else "unlikely",
        "disposable": is_disposable,
        "free": domain in free_providers,
        "role": is_role,
        "sources": [],
    }

def _hunter_lookup(email: str) -> dict:
    if not HUNTER_API_KEY:
        return {}
    try:
        r = requests.get(
            "https://api.hunter.io/v2/email-verifier",
            params={"email": email, "api_key": HUNTER_API_KEY},
            timeout=8,
        )
        data = r.json().get("data", {})
        return {
            "deliverable": data.get("result", "unknown"),
            "mx_records": data.get("mx_records", False),
            "smtp_server": data.get("smtp_server", False),
            "smtp_check": data.get("smtp_check", False),
            "accept_all": data.get("accept_all", False),
            "block": data.get("block", False),
            "disposable": data.get("disposable", False),
            "webmail": data.get("webmail", False),
            "sources": data.get("sources", []),
        }
    except Exception:
        return {}

async def ask_email(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text(
        "📧 *Email Lookup*\n\nSend an email address.\n\nExample: `target@example.com`\n\n"
        "Returns:\n• MX record check\n• Disposable domain check\n• Hunter.io source search",
        parse_mode="Markdown",
        reply_markup=back_keyboard(),
    )
    return AWAITING_EMAIL

async def handle_email(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text.strip().lower()
    if text == "🏠 main menu":
        from handlers.start import start
        return await start(update, ctx)

    if not EMAIL_RE.match(text):
        await update.message.reply_text("❌ Invalid email format.", reply_markup=back_keyboard())
        return AWAITING_EMAIL

    await update.message.reply_text("🔎 Analyzing email...")

    data = _check_email_basic(text)

    # Enrich with Hunter.io if key available
    hunter_data = _hunter_lookup(text)
    if hunter_data:
        data.update(hunter_data)

    result_id = str(uuid.uuid4())[:8]
    ctx.user_data[f"result_{result_id}"] = {"type": "email", "query": text}

    await update.message.reply_text(
        fmt_email(text, data),
        parse_mode="Markdown",
        reply_markup=vote_keyboard(result_id),
    )
    return AWAITING_EMAIL
