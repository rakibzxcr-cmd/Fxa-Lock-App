import os

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
HIBP_API_KEY = os.environ.get("HIBP_API_KEY", "")          # haveibeenpwned.com
NUMVERIFY_KEY = os.environ.get("NUMVERIFY_KEY", "")         # numverify.com
HUNTER_API_KEY = os.environ.get("HUNTER_API_KEY", "")       # hunter.io
IPINFO_TOKEN = os.environ.get("IPINFO_TOKEN", "")           # ipinfo.io (optional)

# Conversation states
(
    CHOOSING,
    AWAITING_IP,
    AWAITING_EMAIL,
    AWAITING_USERNAME,
    AWAITING_PHONE,
    AWAITING_SOCIAL,
    AWAITING_TG_USERNAME,
) = range(7)
